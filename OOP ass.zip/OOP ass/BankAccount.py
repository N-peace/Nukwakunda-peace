class BankAccount:
    interest_rate = 0.05

    def __init__(self, account_holder):
        self.account_holder = account_holder
        self.balance = 0

    def deposit(self, amount):
        self.balance += amount

    def withdraw(self, amount):
        if self.balance >= amount:
            self.balance -= amount
        else:
            print("Insufficient funds.")

    def apply_interest(self):
        interest = self.balance * BankAccount.interest_rate
        self.balance += interest

    def display_account_info(self):
        print(f"Account Holder: {self.account_holder}")
        print(f"Balance: {self.balance}")


account1 = BankAccount("Peace")
account2 = BankAccount("Joshua")

# Perform deposits and withdrawal
account1.deposit(1000)
account1.withdraw(200)
account2.deposit(500)

account1.apply_interest()
account2.apply_interest()

account1.display_account_info()
account2.display_account_info()